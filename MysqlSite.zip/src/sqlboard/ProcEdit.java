package sqlboard;

import util.Ci;
import util.Db;

public class ProcEdit {
	static public void run() {
		String editNo = Ci.rl("수정할 글번호를 입력해 주십시오");
		String edTitle = Ci.rl("제목을 입력해주세요");
		String edId = Ci.rl("작성자 id를 입력해주세요");
		String edContent = Ci.rl("글내용을 입력해주세요");
		Db.dbExecuteUpdate("update cat_board set b_title='"+edTitle+"',b_id='"+edId+"',b_datetime=now(),b_text='"+edContent+"'where b_no="+editNo);
	}
}
