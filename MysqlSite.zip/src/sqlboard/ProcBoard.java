package sqlboard;

import java.sql.SQLException;


import Display.Display;
import util.Ci;
import util.Cw;
import util.Db;

public class ProcBoard {
	public static final int PER_PAGE = 3;
	
	int startIndex = 0; //현재 페이지의 첫 글 인덱스
	int currentPage = 1; //현재 페이지
			
	public static void run() {
		Db.dbInit();
		Display.showTitle();
		loop:while(true) {
			Db.dbPostCount();
			Display.showMainMenu();
			String cmd = Ci.r("명령입력 ");
			switch(cmd) {
			case "1"://글리스트
				ProcList.run();
				break;
			case "2": //글읽기
				ProcRead.run();
				break;
			case "3": //글쓰기
				ProcWrite.run();
				break;
			case "4": //글삭제
				ProcDel.run();
				break;
			case "5": //글수정
				ProcEdit.run();
				break;
			case "6":	//글리스트-검색
				ProcList.search();
				break;
			case "e": //프로그램 종료
				Cw.wn("사이트 메인으로 이동");
				break loop;
			}
		}
	}
}
