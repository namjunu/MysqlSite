package sqlboard;

import java.sql.SQLException;

import util.Ci;
import util.Cw;
import util.Db;

public class ProcRead {
	static public void run() {
			String readNo = Ci.r("읽을 글 번호를 입력해주십시오");
			
		try {
			Db.result = Db.st.executeQuery("select * from cat_board where b_no =" +readNo);
			Db.result.next();
			String title = Db.result.getString("b_title");
			String content = Db.result.getString("b_text");
			Cw.wn("글제목: " + title);
			Cw.wn("글내용: " + content);
			
			//댓글 리스트 출력 처리
			ProcReply.list(Integer.parseInt(readNo));
			
			loop:while(true) {	//명령 입력 받게 하기. 나가기, 댓글쓰기
				String cmd=Ci.r("명령[x:나가기,r:댓글쓰기]");
				switch(cmd) {
				case "x":
					break loop;
				case "r":
					//댓글 쓰기
					ProcReply.write(Integer.parseInt(readNo));
					break;
				default:
					Cw.wn("제대로 입력해주십시오");
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
