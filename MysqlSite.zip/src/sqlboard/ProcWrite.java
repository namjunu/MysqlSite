package sqlboard;

import java.sql.SQLException;

import site.SiteMain;
import util.Ci;
import util.Db;

public class ProcWrite {
	static public void run() {
		String title = Ci.rl("글제목을 입력해주세요 ");
		String text = Ci.rl("글 내용을 입력해 주세요 ");
		try {
			Db.st.executeUpdate("insert into cat_board (b_title,b_id,b_datetime,b_text,b_hit) values ('"+title+"','"+SiteMain.LoginedId+"',now(),'"+text+"',0);");
		} catch (Exception e) {
		}
	}
}
