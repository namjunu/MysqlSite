package sqlboard;

import java.sql.SQLException;

import Display.Display;
import site.SiteMain;
import util.Ci;
import util.Cw;
import util.Db;

public class ProcReply {
	// 댓글 리스트 출력하는 함수
	static public void list(int oriNo) {
		Display.replyBar();
		String sql = "select * from cat_board where b_reply_ori="+oriNo;
		try {
			Cw.wn("전송할 sql문"+sql);
			Db.result = Db.st.executeQuery(sql);
			while(Db.result.next()) {
				String b_id = Db.result.getString("b_id");
				String b_reply_text = Db.result.getString("b_reply_text");
				Cw.wn(b_reply_text+" - "+b_id);
			}
		} catch (SQLException e) {
		}
	}
	
	// 댓글 작성 함수
	static public void write(int b_reply_ori) {
		String b_reply_text = Ci.rl("댓글입력");
		Db.dbExecuteUpdate("insert into cat_board (b_id, b_datetime, b_reply_ori, b_reply_text) values ('"+SiteMain.LoginedId+"', now(), " + b_reply_ori + ", '" + b_reply_text + "')");
	}
}
