package site_display;

import util.Cw;

public class DispSite {
	static private String SITE_NAME = "SQLboard";
	static private String VERSION = " v0.0.4";
	static private String FEAT = " ju.nam";
	static public void entranceTitle() {
		Cw.line();
		Cw.dot();
		Cw.space(22);
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.w(FEAT);
		Cw.space(22);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}	
}
