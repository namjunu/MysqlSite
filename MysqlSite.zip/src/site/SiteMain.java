package site;

import member.ProcMemberLogin;
import member.ProcMemberRegister;
import site_display.DispSite;
import sqlboard.ProcBoard;
import util.Ci;
import util.Cw;
import util.Db;

public class SiteMain {
	static private String cmd = "";
	public static String LoginedId = null;

	static public void run() {
		Db.dbInit();
		
		loop: while (true) {
			DispSite.entranceTitle();
			if(LoginedId==null) {
				cmd = Ci.r("[r]회원가입 [l]로그인 [a]관리자 [e]프로그램종료 [b]게시판(임시입구)");
			} else {
				Cw.wn(LoginedId + " 고객님 환영합니다.");
				cmd = Ci.r("[l]로그아웃 [b]게시판 [a]관리자 [e]프로그램종료 ");
			}
			
			switch (cmd) {
			case "r":
				ProcMemberRegister.run();
				break;
			case "l":
				if(LoginedId==null) {
					LoginedId = ProcMemberLogin.run();
				} else {
					Cw.wn("[로그아웃 됨]");
					LoginedId = null;
				}
				break;
			case "a":
				break;
			case "e":
				Cw.wn("프로그램 종료");
				break loop;
			case "b":
				if(LoginedId==null) {
					Cw.wn("접속할 수 없습니다. 로그인 후 이용하여 주십시오");
				} else {
					ProcBoard.run();
				}
				break;
			default:
				Cw.wn("장난x");
			}
		}
	}
}
